package Exercicio1;

public class Principal {
	
	  public static void main(String[] args){
		  Estudantes e = new Estudantes();
		  for(int i=0;i<10;i++) {
		  e.armazenarEstudantes(e.criarEstudantes());
		  }
		  e.imprimirEstudantes();
		  
	  }

}