package Exercicio1;
import java.util.Random;
import java.util.ArrayList;

public class Estudantes {
	public  String nome; 
	public  int idade; 
	public  char sexo;
	Random r = new Random();
	ArrayList <Estudantes> listaEstudantes = new ArrayList <Estudantes>(); 
	
	public Estudantes criarEstudantes() {
		Estudantes e = new Estudantes();
		e.nome ="Estudante" +r.nextInt(100);
		do {
		e.idade=r.nextInt(20) ;
		}while (e.idade < 17);
		e.sexo='M';
		return e;
		
	}   public void armazenarEstudantes(Estudantes e) {
		listaEstudantes.add(e);
}
	public void imprimirEstudantes() {
		for(Estudantes e: listaEstudantes) {
		System.out.println("Nome: " +e.nome);
		System.out.println("idade: " +e.idade);
        System.out.println("sexo: " +e.sexo);
		}
	}
	
		

}